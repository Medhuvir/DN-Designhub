# UX / Product / Digital Design Skill Toolkit

A working set of Claude skills built for UX, Product, and Service Design practice. Organized by where each one earns its keep in the design process, using Double Diamond as the spine since it's the framework most of these skills already assume.

## How to use this doc

Each stage below lists the skills that apply there, what problem they solve, and when to reach for them. Some skills span more than one stage. They're listed where they do the most work.

---

## Discover
Understanding the problem space before committing to a direction.

**double-diamond**
The framework itself. Use it to structure an entire project or to figure out which diamond you're currently in when a stakeholder wants to skip straight to solutions.

**ux-research-methods**
Picks the right research method for the question you're actually asking. Use this before any research kickoff, especially when someone says "let's just run a survey" without checking if that's the right tool.

---

## Define
Turning raw research into a clear, actionable problem statement and audience.

**ux-personas**
Converts interview notes, survey data, and research findings into research-backed personas. Use after research synthesis, not before, so the personas reflect real data instead of assumptions.

**general-design-review**
A compact combined audit that pulls from multiple frameworks at once. Useful here as a sanity check before moving into concepting, especially on ambiguous problem statements.

---

## Develop
Generating and refining concepts, flows, and interface decisions.

**cognitive-load-conversion**
Audits flows, forms, and layouts for friction and drop-off. Use on any in-progress screen, wireframe, or flow, not just finished designs.

**persuasive-ux**
Applies Fogg's Captology model (motivation, ability, triggers) to engagement and conversion problems. Use when a flow is technically usable but isn't driving the behavior you need.

**ai-tuners**
For AI-powered features specifically: designs the controls that let users shape how the AI interprets input and produces output. Use when scoping what "configurable" should mean for an AI feature.

**ai-inputs**
Designs how users actually prompt or trigger AI behavior in your product. Use alongside ai-tuners when the input mechanism itself (not just the settings) is undecided.

**ai-governors**
Human-in-the-loop and control patterns for AI actions that carry risk or cost. Use when a feature lets AI act autonomously and you need to decide how much oversight to build in.

**ai-trust-builders**
Disclosure, consent, watermarking, and privacy patterns. Use when a feature needs to earn user confidence around what the AI is doing with their data or output.

**ai-identifiers**
Visual and verbal identity for AI features, how the AI presents itself. Use early in concepting a new AI surface, before visual design locks in an identity by accident.

---

## Deliver
Validating, refining, and shipping.

**general-design-review**
Also useful here as a final pass before a design review or stakeholder walkthrough, catching gaps across UX, product, and AI-specific considerations in one lighter pass.

**cognitive-load-conversion**
Re-run on final high-fidelity screens to confirm nothing regressed during visual polish.

---

## Quick reference table

| Skill | Primary stage | Core question it answers |
|---|---|---|
| double-diamond | Discover (all stages) | Where are we in the process, and what comes next? |
| ux-research-methods | Discover | Which research method fits this question? |
| ux-personas | Define | Who are we actually designing for? |
| general-design-review | Define, Deliver | What are we missing across UX, product, and AI? |
| cognitive-load-conversion | Develop, Deliver | Where is this flow creating friction? |
| persuasive-ux | Develop | Why isn't this driving the behavior we want? |
| ai-tuners | Develop | How much control should users have over AI output? |
| ai-inputs | Develop | How do users actually direct the AI? |
| ai-governors | Develop | How do we keep users safe when AI acts on its own? |
| ai-trust-builders | Develop | How do we earn trust around what the AI is doing? |
| ai-identifiers | Develop | How should the AI present itself? |

---

## Folder structure

```
ux-skills-toolkit/
├── README.md                          (this file)
└── skills/
    ├── double-diamond/SKILL.md
    ├── ux-research-methods/SKILL.md
    ├── ux-personas/SKILL.md
    ├── general-design-review/SKILL.md
    ├── cognitive-load-conversion/SKILL.md
    ├── persuasive-ux/SKILL.md
    ├── ai-tuners/SKILL.md
    ├── ai-inputs/SKILL.md
    ├── ai-governors/SKILL.md
    ├── ai-trust-builders/SKILL.md
    └── ai-identifiers/SKILL.md
```

Each skill keeps its original folder name so it can drop straight into a `skills/` directory in any repo that follows the same convention.
